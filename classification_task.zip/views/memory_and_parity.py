#!/usr/bin/env python
# -*- coding: utf-8 -*-

import numpy as np

from matplotlib.ticker import MaxNLocator
import matplotlib.cm as cm

from utils.figure import Figure
import utils.style_config


def show_dataset(X, Y, class_num, img_size):
    fig = Figure(figsize=(15, 7))
    fig.create_grid((2, 5), hspace=0.05, wspace=0.1)
    for idx in range(class_num):
        img = X[Y[:, idx] == 1][0]
        fig[idx].imshow(img.reshape(*img_size), cmap="gray")
        fig[idx].set_xticks([])
        fig[idx].set_yticks([])
        fig[idx].set_title(f"{idx}")


def show_dynamics(record):
    fig = Figure(figsize=(12, 4))
    fig.create_grid((2, 1), hspace=0.0, height_ratios=(1, 4))
    fig[0].plot_matrix(
        record["s"].reshape(1, -1), cmap="binary", aspect="auto", colorbar=False)
    fig[0].set_xticks([])
    fig[0].set_yticks([])
    fig[0].grid(color='k', linestyle=':', linewidth=0.25)

    fig[1].plot(record["x"][:, :10], lw=0.75)
    fig[1].set_ylim([-1.1, 1.1])
    fig[1].line_y(1.0, lw=0.75, ls=":", color="k")
    fig[1].line_y(-1.0, lw=0.75, ls=":", color="k")
    fig[1].set_xlim([-0.5, record["x"].shape[0] - 0.5])
    fig[1].set_xlabel("time step")
    return fig


def show_progress(record):
    fig = Figure(figsize=(16, 6))
    fig.create_grid((1, 2))
    fig[0].line_y(1.0, color="k", lw=1.0, ls=":")
    fig[0].plot(record["train_acc"], label="train")
    fig[0].plot(record["eval_acc"], label="eval")
    fig[0].set_title(
        "Best: {:.4f}/{:.4f}".format(
            np.max(record["train_acc"]), np.max(record["eval_acc"])))
    fig[0].legend()
    fig[0].set_xlabel("Epoch")

    fig[1].create_grid((2, 1), hspace=0.15)
    mat = np.array(record["w_history"], dtype=np.float64).T
    mat[mat == 0] = np.nan
    fig[1][0].plot_matrix(
        mat, y=record["bins"],
        num_label=5, cmap="magma", aspect="auto", colorbar=False)
    fig[1][0].set_xticks([])
    fig[1][0].set_title("log_10(|W|) distribution")

    fig[1][1].set_title("Loss history")
    fig[1][1].plot(record["train_loss"])
    fig[1][1].plot(record["eval_loss"])
    fig[1][1].set_yscale("log")
    fig[1][1].grid(which="minor")
    fig[1][1].xaxis.set_major_locator(MaxNLocator(integer=True))
    l, r = fig[1][1].get_xlim()
    fig[1][0].set_xlim([l + 0.5, r + 0.5])
    fig[1][1].set_xlabel("Epoch")
    return fig


def show_capacity(results):
    mis = results["mis"]
    train_acc = results["train_acc"]
    train_loss = results["train_loss"]

    fig = Figure(figsize=(16, 6))
    fig.create_grid((1, 2))
    fig[0].plot(np.arange(mis.shape[0]) + 1, mis)
    fig[0].set_title("Capacity: {:.4f}".format(mis.sum()))

    delay_max = train_acc.shape[0]

    fig[1].create_grid((2, 1), hspace=0.15)
    for delay in range(delay_max):
        fig[1][0].plot(train_acc[delay], color=cm.rainbow_r(delay / delay_max))
        fig[1][1].plot(train_loss[delay],
                       color=cm.rainbow_r(delay / delay_max))
    fig[1][0].set_title("Training accuracy")
    fig[1][0].set_xticklabels([])
    fig[1][1].set_title("Training loss")
    fig[1][1].grid("major")
    fig[1][1].set_yscale("log")
    return fig


def show_results(delay, X_eval, S_in, D_eval, D_out, Y_eval, Y_out):
    fig = Figure(figsize=(12, 8))
    fig.create_grid((4, 1), hspace=0.0, height_ratios=(1, 1, 1, 3))
    fig[0].set_title(f"Delay={delay}")
    fig[0].plot_matrix(
        S_in.reshape(1, -1), cmap="binary", aspect="auto", colorbar=False)
    fig[0].set_xticks([])
    fig[0].set_yticks([])
    fig[0].grid(color='k', linestyle=':', linewidth=0.25)
    fig[0].set_ylabel("s")

    fig[1].plot(D_eval, color="black", ls=":")
    fig[1].plot(D_out, color="red")
    fig[1].set_xticks([])
    fig[1].set_yticks([])
    fig[1].set_xlim([-0.5, X_eval.shape[0] - 0.5])
    fig[1].set_ylabel("d & s_out")

    fig[2].plot(Y_out, color="green")
    fig[2].set_xticks([])
    fig[2].set_yticks([])
    fig[2].set_xlim([-0.5, X_eval.shape[0] - 0.5])
    fig[2].set_ylabel("Prob")

    fig[3].plot(
        X_eval[:, :10], lw=0.75, markeredgewidth=0.0,
        markersize=4.0, marker="None")
    fig[3].set_ylim([-1.1, 1.1])
    fig[3].line_y(1.0, lw=0.75, ls=":", color="k")
    fig[3].line_y(-1.0, lw=0.75, ls=":", color="k")
    fig[3].set_xlim([-0.5, X_eval.shape[0] - 0.5])
    return fig
