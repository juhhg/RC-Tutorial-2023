#!/usr/bin/env python
# -*- coding: utf-8 -*-

import numpy as np
import traceback


def test_softmax(func):
    def softmax(a):
        a_max = a.max(axis=1, keepdims=True)
        a_exp = np.exp(a - a_max)
        y = a_exp / np.sum(a_exp, axis=1, keepdims=True)
        return y
    try:
        x = np.arange(48).reshape(8, 6)
        y = func(x)
        y_ans = softmax(x)
        assert np.allclose(y, y_ans)
        print("OK!")
    except Exception as e:
        print("Something went wrong!")
        print(e)
        traceback.print_exc()


def test_cross_entropy(func):
    def cross_entropy(y, t, ep=1e-10):
        L = -(t * np.log(np.clip(y, ep, 1 - ep))).sum(axis=1).mean()
        return L

    try:
        y = np.array([[0.6, 0.2, 0.9, 0.9, 0.1, 0.2, 0, 1]])
        t = np.array([[1, 0, 1, 1, 0, 1, 1, 0]])
        L = func(y, t)
        L_ans = cross_entropy(y, t)
        assert np.allclose(L, L_ans)
        print("OK!")
    except Exception as e:
        print("Something went wrong!")
        print(e)
        traceback.print_exc()


def test_gradient_decent(_class):
    def softmax(x):
        x_max = x.max(axis=1, keepdims=True)
        x_exp = np.exp(x - x_max)
        y = x_exp / np.sum(x_exp, axis=1, keepdims=True)
        return y

    def gradient(x, y, t):
        delta = y - t
        gW = np.dot(x.T, delta) / x.shape[0]
        gb = np.sum(delta, axis=0) / x.shape[0]
        return gW, gb

    def step(W, b, x, t, ep):
        y = softmax(np.dot(x, W) + b)
        gW, gb = gradient(x, y, t)
        W = W - ep * gW
        b = b - ep * gb
        return W, b

    try:
        model = _class(5, 5)
        W, b = model.W.copy(), model.b.copy()
        x = np.array([[1, 2, 3, 4, 5]])
        t = np.array([[1, 0, 0, 0, 0]])
        lr = 1.0
        model.step(x, t, lr)
        W, b = step(W, b, x, t, lr)
        assert np.allclose(W, model.W)
        assert np.allclose(b, model.b)
        print("OK!")
    except Exception as e:
        print("Something went wrong!")
        print(e)
        traceback.print_exc()
