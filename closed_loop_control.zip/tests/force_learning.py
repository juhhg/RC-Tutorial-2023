#!/usr/bin/env python
# -*- coding: utf-8 -*-

import numpy as np
from .tester import check_error


def test_rls_update(func):
    def rls_update(P, x):
        k = P.dot(x)
        g = 1 / (1 + x.dot(k))
        dP = g * np.outer(k, k)
        P_new = P - dP
        return g, k, P_new

    rnd = np.random.RandomState(1234)
    P = rnd.randn(10, 10)
    P = P.dot(P.T)
    x = rnd.randn(10)
    res = check_error(rls_update, func, P, x)
    print(res if res else "OK!")


def test_force_readout(_class):
    def rls_update(P, x):
        k = P.dot(x)
        g = 1 / (1 + x.dot(k))
        dP = g * np.outer(k, k)
        P_new = P - dP
        return g, k, P_new

    class Answer(_class):
        def step(self, x, d):
            assert x.ndim == 1
            e = d - self(x)
            dws = np.zeros_like(self.w)
            for idx in range(self.output_dim):
                P = self.Ps[idx]
                g, k, P_new = rls_update(P, x)
                dw = g * e[idx] * k
                self.Ps[idx] = P_new
                self.w[idx, :] += dw
                dws[idx, :] = dw
            return dws

    model_des = Answer(10, 3, seed=1234)
    model_out = _class(10, 3, seed=1234)
    x = np.arange(10)
    d = np.arange(3)
    res = check_error(model_des.step, model_out.step, x, d)
    print(res if res else "OK!")
