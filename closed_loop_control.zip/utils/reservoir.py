#!/usr/bin/env python
# -*- coding: utf-8 -*-

import numpy as np

try:
    from scipy.sparse.linalg.eigen.arpack import eigs, ArpackNoConvergence
except Exception:
    from scipy.sparse.linalg import eigs, ArpackNoConvergence


class Module(object):
    def __init__(self, *args, seed=None, rnd=None, dtype=np.float64, **kwargs):
        if rnd is None:
            self.rnd = np.random.RandomState(seed)
        else:
            self.rnd = rnd
        self.dtype = dtype


class ESN(Module):
    def __init__(
            self, dim, f=np.tanh, g=1.0, a=None, p=1.0,
            bias=None, init_state=None, normalize=True, **kwargs):
        '''
        Echo state network [Jaeger, H. (2001). Bonn, Germany: German National Research Center for Information Technology GMD Technical Report, 148(34), 13.]

        Args:
            dim (int): number of the ESN nodes
            f (func, optional): activation function. Defaults to np.tanh.
            g (float, optional): nonlinear coefficient. Defaults to 1.0.
            a (float, optional): leaky rate. Defaults to None.
            p (float, optional): density of connection matrix. Defaults to 1.0.
            bias (optional): bias term. Defaults to None.
            init_state (optional): initial states. Defaults to None.
            normalize (bool, optional): normalizing connection matrix. Defaults to True.
        '''
        super(ESN, self).__init__(**kwargs)
        self.dim = dim
        self.f = f  # activation function
        self.g = g  # nonlinearity
        self.p = p  # matrix density
        self.a = a  # leaky rate
        self.bias = bias  # bias term
        if init_state is None:  # initial values
            self.x_init = np.zeros(dim, dtype=self.dtype)
        else:
            self.x_init = np.array(init_state, dtype=self.dtype)
        self.x = np.array(self.x_init)

        # generating normalzied sparse matrix (p: density prob.)
        while True:
            try:
                coeff = 1.0 / np.sqrt(self.dim * self.p)  # circular law
                self.w_net = self.rnd.randn(self.dim, self.dim).astype(self.dtype) * coeff
                w_con = np.full((dim * dim,), False)
                w_con[:int(dim * dim * self.p)] = True
                self.rnd.shuffle(w_con)
                w_con = w_con.reshape((dim, dim))
                self.w_net = self.w_net * w_con  # sparse matrix
                if normalize:
                    eigen_values = eigs(self.w_net, return_eigenvectors=False, k=min(self.dim, 6), which="LM", v0=np.ones(self.dim))
                    spectral_radius = max(abs(eigen_values))
                    self.w_net = self.w_net / spectral_radius
                break
            except ArpackNoConvergence:
                continue

    def step(self, u=None):
        x_in = self.g * np.matmul(self.x, self.w_net.swapaxes(-1, -2))
        if u is not None:
            x_in += u
        if self.bias is not None:
            x_in += self.bias
        if self.a is None:
            self.x = self.f(x_in)
        else:
            self.x = (1 - self.a) * self.x + self.a * self.f(x_in)

    def step_while(self, num_step, **kwargs):
        for _ in range(num_step):
            self.step(**kwargs)

    def reset(self, x=None):
        if x is None:
            self.x = np.array(self.x_init)
        else:
            self.x = np.array(x)
