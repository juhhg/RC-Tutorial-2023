#!/usr/bin/env python
# -*- coding: utf-8 -*-

import numpy as np
from .tester import check_error


def test_innate_esn(_class):
    def rls_update(P, x):
        k = P.dot(x)
        g = 1 / (1 + x.dot(k))
        dP = g * np.outer(k, k)
        P_new = P - dP
        return g, k, P_new

    class Answer(_class):
        def __init__(self, *args, alpha=1.0, pre_node=None, post_node=None, **kwargs):
            super(_class, self).__init__(*args, **kwargs)
            self.alpha = alpha
            if pre_node is None:
                pre_node = range(self.dim)
            if post_node is None:
                post_node = range(self.dim)
            self.w_pre = {}
            self.P = {}
            for post in post_node:
                non_zeros = self.w_net[post].nonzero()[0]
                selected_id = np.isin(non_zeros, pre_node)
                self.w_pre[post] = non_zeros[selected_id]
                self.P[post] = np.eye(len(self.w_pre[post])) / self.alpha  # RIGHT initialize P

        def train(self, x_target, x_now=None, neuron_list=None):
            if x_now is None:
                x_now = np.asarray(self.x)
            if neuron_list is None:
                neuron_list = range(self.dim)
            for xt, xn in zip(x_target.reshape(-1, self.dim), x_now.reshape(-1, self.dim)):
                es = xt[neuron_list] - xn[neuron_list]
                for node_id, e in zip(neuron_list, es):
                    x = xn[self.w_pre[node_id]]  # RIGHT use self.w_pre. (big hint: x = xn[...])
                    P = self.P[node_id]  # RIGHT self.P
                    g, k, P_new = rls_update(P, x)
                    dw = g * e * k  # RIGHT
                    self.P[node_id] = P_new
                    self.w_net[node_id, self.w_pre[node_id]] += dw
            return self.w_net

    test_cases = [
        [1, 100, 10.0, None, 1234],
        [2, 200, 1.0, np.arange(100), 5678],
        [3, 300, 0.1, range(100), 9102],
    ]

    for size, net_dim, alpha, neuron_list, seed in test_cases:
        rnd = np.random.RandomState(seed)
        model_des = Answer(net_dim, a=0.1, alpha=alpha, seed=seed)
        model_out = _class(net_dim, a=0.1, alpha=alpha, seed=seed)
        x_target = rnd.randn(size, net_dim)
        x_now = rnd.randn(size, net_dim)
        res = check_error(
            model_des.train, model_out.train,
            x_target, x_now=x_now, neuron_list=neuron_list)
        if res:
            print(res)
            return
    print("OK!")
