#!/usr/bin/env python
# -*- coding: utf-8 -*-

'''
Modified from https://pypi.org/project/ddeint/
(Repo: https://github.com/Zulko/ddeint)


This module implements ddeint, a simple Differential Delay Equation
solver built on top of Scipy's odeint
'''


import numpy as np
import scipy.integrate
import scipy.interpolate

from .tqdm import tqdm


class DDEVar:
    '''
    The instances of this class are special function-like
    variables which store their past values in an interpolator and
    can be called for any past time: Y(t), Y(t-d).
    Very convenient for the integration of DDEs.
    '''

    def __init__(self, g, tc=0):
        '''
        g(t) = expression of Y(t) for t<tc
        '''
        self.g = g
        self.tc = tc
        # NOTE We must fill the interpolator with 2 points minimum

        self.interpolator = scipy.interpolate.interp1d(
            np.array([tc - 1, tc]),  # X
            np.array([self.g(tc), self.g(tc)]).T,  # Y
            kind="linear",
            bounds_error=False,
            fill_value=self.g(tc)
        )

    def update(self, t, Y):
        '''
        Add one new (ti,yi) to the interpolator
        '''
        Y2 = Y if (Y.size == 1) else np.array([Y]).T
        self.interpolator = scipy.interpolate.interp1d(
            np.hstack([self.interpolator.x, [t]]),  # X
            np.hstack([self.interpolator.y, Y2]),  # Y
            kind="linear",
            bounds_error=False,
            fill_value=Y
        )

    def __call__(self, t=0):
        '''
        Y(t) will return the instance's value at time t
        '''
        return self.g(t) if (t <= self.tc) else self.interpolator(t)


class DDE(scipy.integrate.ode):
    '''
    This class overwrites a few functions of ``scipy.integrate.ode``
    to allow for updates of the pseudo-variable Y between each
    integration step.
    '''

    def __init__(self, f, jac=None):
        def f2(t, y, args):
            return f(self.Y, t, *args)

        scipy.integrate.ode.__init__(self, f2, jac)
        self.set_f_params(None)

    def integrate(self, t, step=0, relax=0):
        scipy.integrate.ode.integrate(self, t, step, relax)
        self.Y.update(self.t, self.y)
        return self.y

    def set_initial_value(self, Y):
        self.Y = Y  # NOTE Y will be modified during integration
        scipy.integrate.ode.set_initial_value(self, Y(Y.tc), Y.tc)


def ddeint(func, g, tt, fargs=None, name="vode", **kwargs):
    '''
    Solves Delay Differential Equations
    Similar to scipy.integrate.odeint. Solves a Delay differential
    Equation system (DDE) defined by

        Y(t) = g(t) for t < 0
        Y'(t) = func(Y, t) for t >= 0

    Where func can involve past values of Y, like Y(t-d).

    Args:
        func (callable):
            a function Y,t,args -> Y'(t), where args is optional.
            The variable Y is an instance of class DDEVar, which means that
            it is called like a function: Y(t), Y(t-d), etc. Y(t) returns
            either a number or a numpy array (for multivariate systems).
        g (callable):
            The 'history function'. A function g(t)=Y(t) for t<0, g(t)
            returns either a number or a numpy array (for multivariate
            systems).

        tt (np.ndarray):
            The vector of times [t0, t1, ...] at which the system must
            be solved.
        fargs (list, optional):
            Additional arguments to be passed to parameter ``func``, if any.
            defaults to None.
        name (str, optional):
            A function name. Defaults to "vode".

    Returns:
        np.ndarray: results
    '''
    dde = DDE(func)
    # dde_.set_integrator(name, **kwargs)
    dde.set_initial_value(DDEVar(g, tt[0]))
    dde.set_f_params(fargs if fargs else [])
    yy = np.zeros((len(tt), *dde.y.shape))
    yy[0] = dde.y
    for idx, dt in enumerate(tqdm(np.diff(tt))):
        yy[idx + 1] = dde.integrate(dde.t + dt)
    return yy
