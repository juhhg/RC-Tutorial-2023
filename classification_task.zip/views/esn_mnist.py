#!/usr/bin/env python
# -*- coding: utf-8 -*-

import numpy as np

from matplotlib.ticker import MaxNLocator

from utils.figure import Figure
import utils.style_config


def show_dataset(X, Y, class_num, img_size):
    fig = Figure(figsize=(15, 7))
    fig.create_grid((2, 5), hspace=0.05, wspace=0.1)
    for idx in range(class_num):
        img = X[Y[:, idx] == 1][0]
        fig[idx].imshow(img.reshape(*img_size), cmap="gray")
        fig[idx].set_xticks([])
        fig[idx].set_yticks([])
        fig[idx].set_title(f"{idx}")


def show_dynamics(record):
    img = record["img"].reshape(-1, record["img"].shape[-1])
    x = record["x"].reshape(-1, record["x"].shape[-1])
    fig = Figure(figsize=(12, 5))
    fig.create_grid((2, 1), hspace=0.0, height_ratios=(3, 8))
    fig[0].plot_matrix(img.T, cmap="gray", aspect="auto", colorbar=False)
    fig[0].set_xticks([])
    fig[0].set_yticks([])
    fig[0].grid(color='k', linestyle=':', linewidth=0.25)

    fig[1].plot(x[..., :10], lw=0.75)
    fig[1].set_ylim([-1.1, 1.1])
    fig[1].line_y(1.0, lw=0.75, ls=":", color="k")
    fig[1].line_y(-1.0, lw=0.75, ls=":", color="k")
    fig[1].set_xlim([-0.5, record["x"].shape[0] - 0.5])
    fig[1].set_xlabel("time step")
    return fig


def show_progress(record):
    fig = Figure(figsize=(16, 6))
    fig.create_grid((1, 2))
    fig[0].line_y(1.0, color="k", lw=1.0, ls=":")
    fig[0].plot(record["train_acc"], label="train")
    fig[0].plot(record["eval_acc"], label="eval")
    fig[0].set_title(
        "Best: {:.4f}/{:.4f}".format(
            np.max(record["train_acc"]), np.max(record["eval_acc"])))
    fig[0].legend()
    fig[0].set_xlabel("Epoch")

    fig[1].create_grid((2, 1), hspace=0.15)
    mat = np.array(record["w_history"], dtype=np.float64).T
    mat[mat == 0] = np.nan
    fig[1][0].plot_matrix(
        mat, y=record["bins"],
        num_label=5, cmap="magma", aspect="auto", colorbar=False)
    fig[1][0].set_xticks([])
    fig[1][0].set_title("log_10(|W|) distribution")

    fig[1][1].set_title("Loss history")
    fig[1][1].plot(record["train_loss"])
    fig[1][1].plot(record["eval_loss"])
    fig[1][1].set_yscale("log")
    fig[1][1].grid(which="minor")
    fig[1][1].xaxis.set_major_locator(MaxNLocator(integer=True))
    l, r = fig[1][1].get_xlim()
    fig[1][0].set_xlim([l + 0.5, r + 0.5])
    fig[1][1].set_xlabel("Epoch")
    return fig
