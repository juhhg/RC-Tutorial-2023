#!/usr/bin/env python
# -*- coding: utf-8 -*-

import numpy as np
import traceback


def test_linear(_class):
    def predict(w, x):
        y = np.matmul(np.asarray(x), w.swapaxes(-1, -2))
        return y
    try:
        model = _class(3, 4, seed=1234)
        x = np.array([1, 2, 3])
        y = model.predict(x)
        y_out = predict(model.w, x)
        assert np.allclose(y, y_out)
        print("OK!")
    except Exception as e:
        print("Something went wrong!")
        print(e)
        traceback.print_exc()


def test_esn(_class):
    def step(net, x, u=None):
        x_in = net.g * np.matmul(x, net.w_net.swapaxes(-1, -2))
        if u is not None:
            x_in += u
        if net.bias is not None:
            x_in += net.bias
        if net.a is None:
            return net.f(x_in)
        else:
            return (1 - net.a) * x + net.a * net.f(x_in)

    try:
        x_init = np.linspace(-1, 1, 10)
        u = np.linspace(-1, 1, 10)[::-1]
        model = _class(dim=10, g=0.9, normalize=True, init_state=x_init, seed=1234)
        model.step(u)
        x = np.array(model.x)
        x_out = step(model, x_init, u)
        assert np.allclose(x, x_out)
        print("OK!")
    except Exception as e:
        print("Something went wrong!")
        print(e)
        traceback.print_exc()
