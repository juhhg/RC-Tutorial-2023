#!/usr/bin/env python
# -*- coding: utf-8 -*-

import numpy as np
from utils.figure import Figure


def show_trajectory(
        rec_t, rec_net, plot_range,
        t_range=slice(None), fig=None,
        title=None, clear=False, cmap=None,
        pulse_range=None, innate_range=None, **kwargs):
    plot_num = len(plot_range)
    create_new_fig = fig is None
    if create_new_fig:
        fig = Figure(figsize=(16, plot_num * 1.6))
        fig.create_grid((plot_num, 1), wspace=0.0, hspace=0.0)

    if clear or create_new_fig:
        for idx in range(plot_num):
            fig[idx].cla()
            fig[idx].set_xlim([rec_t[0], rec_t[-1]])
            fig[idx].set_ylim([-1.1, 1.1])
            if pulse_range is not None:
                fig[idx].fill_x(*pulse_range, facecolor="gray", alpha=0.5)
            if innate_range is not None:
                fig[idx].fill_x(*innate_range, facecolor="pink", alpha=0.5)

    if title is not None:
        fig[0].set_title(title)
    for idx in range(plot_num):
        fig[idx].set_yticklabels([])
        if idx < plot_num - 1:
            fig[idx].set_xticklabels([])
        fig[idx].grid(True)

    for symbol_id, x in enumerate(np.rollaxis(rec_net, -2)):
        if cmap is not None:
            kwargs["color"] = cmap(symbol_id)
        for idx, node_id in enumerate(plot_range):
            fig[idx].plot(
                rec_t[t_range], x[t_range, ..., node_id], **kwargs)
    return fig


def show_error(error_history, fig=None, **kwargs):
    if fig is None:
        fig = Figure(figsize=(8, 5))
    else:
        fig[0].cla()
    error_mean = np.mean(error_history, axis=1)
    error_std = np.std(error_history, axis=1)
    error_best_epoch = error_mean.sum(axis=1).argmin()
    for mean, std in zip(error_mean.T, error_std.T):
        fig[0].fill_std(np.arange(mean.shape[0]), mean, std)
    fig[0].set_ylim([0, None])
    # fig[0].set_yscale("log")
    fig[0].line_x(error_best_epoch, ls=":", color="black")
    fig[0].set_title("best: {}".format(error_best_epoch))
    return fig


def show_output(ts, xs, ys, ds, fig=None, title=None, label=None, clear=False):
    create_new_fig = fig is None
    if create_new_fig:
        fig = Figure(figsize=(8, 4))
        fig.create_grid((2, 1), wspace=0.0, hspace=0.0)
    fig[0].plot(ts, xs.mean(axis=2), lw=1.0, label=label)
    fig[0].set_xticklabels([])
    fig[0].set_ylabel("mean of xs")
    if title is not None:
        fig[0].set_title(title)
    fig[1].plot(ts, ds, lw=2.0, ls=":", color="k", label=label)
    fig[1].plot(ts, ys, lw=1.0)
    fig[1].set_ylabel("out")
    return fig
