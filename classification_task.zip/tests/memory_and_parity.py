#!/usr/bin/env python
# -*- coding: utf-8 -*-

import itertools
import traceback
import numpy as np
from utils.figure import Figure


def test_symbol_input(_class):
    def predict(w, s):
        y = w[s]
        return y
    try:
        model = _class(10, 3, seed=1234)
        s = np.array([0, 1, 2, 0])
        y = model.predict(s)
        y_out = predict(model.w_in, s)
        assert np.allclose(y, y_out)
        print("OK!")
    except Exception as e:
        print("Something went wrong!")
        print(e)
        traceback.print_exc()


def test_mutual_information(func):
    def calc_mutual_information(X, Y, class_num, ep=1e-10):
        assert X.shape[0] == Y.shape[0]
        mi = 0.0
        for _p, _q in itertools.product(range(class_num), range(class_num)):
            b_x = (X == _p)
            b_y = (Y == _q)
            p_x = b_x.mean()
            p_y = b_y.mean()
            p_xy = np.logical_and(b_x, b_y).mean() + ep
            mi += p_xy * np.log2(p_xy / (p_x * p_y + ep))
        return mi
    try:
        x1 = np.random.randint(0, 2, 1000)
        x2 = np.random.randint(0, 2, 1000)
        mi1 = func(x1, x2, 2)
        mi2 = calc_mutual_information(x1, x2, 2)
        diff = np.linalg.norm(mi1 - mi2)
        assert diff < 1e-10
        print("OK!")
    except Exception as e:
        print("Something wrong")
        print(e)
        traceback.print_exc()


def test_memory_task(*args, **kwargs):
    def memory_task(s, length, delay):
        assert length > 0 and delay > 0
        s_in = s[-length:]
        d_n = s[-(length + delay):-delay]
        return s_in, d_n
    return test_task(memory_task, *args, **kwargs)


def test_parity_task(*args, **kwargs):
    def parity_task(s, length, delay):
        assert length > 0 and delay > 0
        s_in = s[-length:]
        d_n = np.convolve(s[-(length + delay):-1],
                          np.ones(delay), mode="valid") % 2
        d_n = d_n.astype(np.int8)
        return s_in, d_n
    return test_task(parity_task, *args, **kwargs)


def test_task(func1, func2, *args, **kwargs):
    try:
        s = np.random.randint(0, 2, 1000)
        s1, d1 = func1(s, 100, 200)
        s2, d2 = func2(s, 100, 200)
        diff = np.linalg.norm(s1 - s2)
        diff += np.linalg.norm(d1 - d2)
        assert diff < 1e-10
        print("OK!")
    except Exception as e:
        print("Something wrong")
        print(e)
        traceback.print_exc()
        return
    return show_func(func2, *args, **kwargs)


def show_func(func, s, length, n_max):
    def show_bar(ax, mat, label=""):
        ax.plot_matrix(
            mat.reshape(1, -1), cmap="binary", aspect="auto", colorbar=False)
        ax.set_xticks([])
        ax.set_yticks([])
        ax.set_ylabel(label)

    fig = Figure(figsize=(12, 5))
    fig.create_grid((n_max + 1, 1), hspace=0)
    for delay in range(1, n_max + 1):
        s_in, d_n = func(s, length, delay)
        show_bar(fig[delay], d_n, f"{delay}")
    show_bar(fig[0], s_in, "")
    fig[n_max].set_xlabel("time step")
    return fig
