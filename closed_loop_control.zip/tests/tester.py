
import json
import itertools
import traceback
import numpy as np


def get_ndarray_info(arr, prefix=""):
    out = {}
    with np.printoptions(edgeitems=2, threshold=5, linewidth=np.inf, precision=6):
        out["value"] = str(arr)
    out["shape"] = str(arr.shape)
    return out


def get_variables_info(*args, **kwargs):
    out = {}
    iterations = itertools.chain(
        [(f"#{idx + 1}", arg) for idx, arg in enumerate(args)],
        kwargs.items())
    for key, val in iterations:
        out[key] = dict(
            type=type(val).__name__
        )
        if type(val) is np.ndarray:
            out[key].update(get_ndarray_info(val))
        else:
            out[key]["value"] = str(val)
    return out


def check_error(func_sol, func_out, *args, **kwargs) -> str | None:
    try:
        ret_sol = func_sol(*args, **kwargs)
        ret_out = func_out(*args, **kwargs)
        if type(ret_sol) is not type(ret_out):
            raise ValueError("Return formats are different!")
        try:
            if type(ret_sol) is not tuple:
                ret_sol = (ret_sol,)
                ret_out = (ret_out,)
            assert len(ret_sol) == len(ret_out), "Return numbers are different!"
            for out_id, (sol, out) in enumerate(zip(ret_sol, ret_out)):
                assert type(ret_sol) is type(ret_out), f"return #{out_id + 1}'s types are different!"
                if type(sol) is np.ndarray:
                    assert sol.shape == out.shape, f"Return #{out_id + 1}'s shapes are different!"
                    assert np.allclose(sol, out), f"Return #{out_id + 1}'s values are not close!"
                elif np.isscalar(sol):
                    assert sol == out, f"Return #{out_id + 1}'s values are not close!"
            return None
        except AssertionError as e:
            errmsg = f"NG! {e}\n"
            info_dict = {}
            info_dict["Argument(s)"] = get_variables_info(*args, **kwargs)
            info_dict["Return(s) (desired)"] = get_variables_info(*ret_sol)
            info_dict["Return(s) (yours)"] = get_variables_info(*ret_out)
            errmsg += json.dumps(info_dict, indent=4, default=str)
            return errmsg
    except Exception as e:
        errmsg = "Something went wrong! Cannot get outputs!\n"
        errmsg += f"{e}\n"
        errmsg += traceback.format_exc()
        return errmsg
