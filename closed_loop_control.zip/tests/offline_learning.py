#!/usr/bin/env python
# -*- coding: utf-8 -*-

import numpy as np
from .tester import check_error


def test_ridge_regression(_class):
    def answer(X, Y, alpha=0):
        assert X.shape[0] == Y.shape[0]
        A = np.dot(X.T, X)
        B = np.dot(X.T, Y)
        if alpha > 0:
            dim = X.shape[1]
            A += alpha * np.eye(dim)
        sol, _residuals, _rank, _s = np.linalg.lstsq(A, B, rcond=None)
        return sol.T

    test_cases = [
        [100, 10, 3, 1e-4, 1234],
        [200, 12, 5, 0.0, 1234],
        [300, 15, 7, 1e0, 1234],
    ]
    for dim_batch, dim_in, dim_out, alpha, seed in test_cases:
        model = _class(dim_in, dim_out, seed=seed)
        x = np.random.randn(dim_batch, dim_in)
        y = np.random.randn(dim_batch, dim_out)
        res = check_error(answer, model.train, x, y, alpha=alpha)
        if res:
            print(res)
            return
    print("OK!")


def test_runge_kutta(func):
    def runge_kutta(func, x0, ts, **params):
        x = np.array(x0)
        ys = np.zeros((len(ts), *x.shape))
        ys[0] = x
        for idx, dt in enumerate(np.diff(ts)):
            k1 = dt * func(x, ts[idx], **params)
            k2 = dt * func(x + 0.5 * k1, ts[idx] + 0.5 * dt, **params)
            k3 = dt * func(x + 0.5 * k2, ts[idx] + 0.5 * dt, **params)
            k4 = dt * func(x + k3, ts[idx] + dt, **params)
            x += (k1 + 2 * k2 + 2 * k3 + k4) / 6
            ys[idx + 1] = x
        return ys

    def test_func(x, t):
        x_dot = np.zeros_like(x)
        x_dot[0] = x[0] - x[1] - x[0] * (x[0]**2 + x[1] ** 2) + np.cos(t / 60)
        x_dot[1] = x[0] + x[1] - x[1] * (x[0]**2 + x[1] ** 2) + np.sin(t / 60)
        return x_dot

    res = check_error(runge_kutta, func, test_func, [1.0, 1.0], np.linspace(0, 1, 100))
    print(res if res else "OK!")


def test_lorenz(func):
    def lorenz_eqn(x, _t, a=10.0, b=28.0, c=8.0 / 3.0):
        x_dot = np.zeros_like(x)
        x_dot[0] = a * (x[1] - x[0])  # RIGHT
        x_dot[1] = x[0] * (b - x[2]) - x[1]  # RIGHT
        x_dot[2] = x[0] * x[1] - c * x[2]  # RIGHT
        return x_dot

    res = check_error(lorenz_eqn, func, [1.0, 1.0, 1.0], 0)
    print(res if res else "OK!")


def test_mackey_glass(func):
    def mackey_glass_eqn(x, t, tau=17):
        x_dot = 0.2 * x(t - tau) / (1 + x(t - tau)**10) - 0.1 * x(t)  # RIGHT
        return x_dot

    def test_func(t):
        return t ** 2

    res = check_error(mackey_glass_eqn, func, test_func, 0, tau=12)
    print(res if res else "OK!")
