#!/usr/bin/env python
# -*- coding: utf-8 -*-

import numpy as np
import pandas as pd
import plotly.express as px
# import plotly.graph_objects as go

from utils.figure import Figure
from utils.style_config import cmap


def show_record(record, xlim=None):
    t = record["t"]
    x = record["x"]
    y = record["y"]
    if "d" in record:
        d = record["d"]
    else:
        d = None
    if d is None:
        fig = Figure(figsize=(12, 5))
        fig.create_grid((2, 1), hspace=0.0, height_ratios=(4, 1))
    else:
        fig = Figure(figsize=(12, 6))
        fig.create_grid((3, 1), hspace=0.0, height_ratios=(4, 1, 1))

    axes = []
    fig[0].plot(t, x[:, :10], lw=0.75)
    fig[0].set_ylim([-1.1, 1.1])
    fig[0].line_y(1.0, lw=0.75, ls=":", color="k")
    fig[0].line_y(-1.0, lw=0.75, ls=":", color="k")
    fig[0].set_ylabel("ESN dynamics")
    fig[0].set_xticklabels([])
    axes.append(fig[0])

    fig[1].plot(t, y, lw=0.75, color=cmap(0))
    fig[1].set_ylabel("y")
    fig[1].set_xlabel("Time steps")
    axes.append(fig[1])

    if d is not None:
        fig[1].plot(t, d, ls=":", lw=0.75, color="k")
        fig[1].set_xticklabels([])
        fig[1].set_xlabel("")
        fig[1].set_ylabel("y & d")
        fig[2].plot(t, np.abs(y - d), lw=0.75, color="green")
        fig[2].set_yscale("log")
        fig[2].set_ylabel("diff")
        fig[2].set_xlabel("Time steps")
        axes.append(fig[2])
    for ax in axes:
        ax.fill_x(*record["open_range"], alpha=0.4, facecolor="cyan")
        if xlim is not None:
            ax.set_xlim(xlim)
    return fig


def show_3d_coord(*args, **data_dict):
    if len(args) > 0:
        iters = enumerate(args)
    else:
        iters = data_dict.items()
    df_list = []
    for key, val in iters:
        assert val.ndim == 2 and val.shape[-1] == 3
        df = pd.DataFrame(dict(x=val[:, 0], y=val[:, 1], z=val[:, 2]))
        df = df.assign(label=key)
        df_list.append(df)
    df = pd.concat(df_list)
    fig = px.line_3d(data_frame=df, x="x", y="y", z="z", color="label" if len(data_dict) > 1 else None)
    fig.update_layout(
        autosize=False,
        width=800,
        height=800,
        scene=dict(
            camera=dict(
                up=dict(x=0, y=0, z=1),
                center=dict(x=0, y=0, z=0),
                eye=dict(x=1.25, y=-1.25, z=1.25)
            )
        )
    )
    return fig


def construct_delayed_coord(data, tau, ndim=2):
    assert data.ndim == 1 or data.shape[-1] == 1
    if data.ndim == 1:
        data = data[:, None]
    length = data.shape[0]
    return np.concatenate([data[tau * d: length - tau * (ndim - d)] for d in range(ndim)], axis=-1)


def show_delayed_coord(*args, tau=10, labels=None, **kwargs):
    if len(args) == 1:
        y = args[0]
        fig = Figure(figsize=(6, 6))
        fig[0].plot(y[:-tau], y[tau:], lw=0.2, **kwargs)
    else:
        n_fig = len(args) + 1
        fig = Figure(figsize=(8 * n_fig, 6))
        fig.create_grid((1, n_fig), hspace=0.15)
        for idx, y in enumerate(args):
            fig[idx].plot(y[:-tau], y[tau:], lw=0.25,
                          color=cmap(idx), **kwargs)
            fig[idx].set_xlabel(r"$x_{}(t)$".format(idx + 1))
            fig[idx].set_ylabel(r"$x_{}(t+\tau)$".format(idx + 1))
            fig[-1].plot(y[:-tau], y[tau:], lw=0.25, color=cmap(idx), **kwargs)
            fig[idx].set_aspect("equal", "datalim")
            if labels is not None and idx < len(labels):
                fig[idx].set_title(labels[idx])
        fig[-1].set_aspect("equal", "datalim")
    return fig
